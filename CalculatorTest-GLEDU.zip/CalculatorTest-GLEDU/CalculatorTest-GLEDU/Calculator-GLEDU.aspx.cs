﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CalculatorTest_GLEDU
{
    public partial class Calculator_GLEDU : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
        }

        protected void btn_AddValues_Click(object sender, EventArgs e)
        {

            decimal ValueA = 0;
            decimal ValueB = 0; //Set default values for the user inputs
            try
            {
                ValueA = decimal.Parse(txt_ValueA.Text);

                ValueB = decimal.Parse(txt_ValueB.Text); //Tries to parse the user inputs as decimals
            }
            catch
            {
                //If the users inputs cannot be parsed, the values will still be equal to zero
            }

            SimpleCalculation p = new SimpleCalculation(); //A new instance of the SimpleCalculation class

            decimal CalcResult = p.Add(ValueA, ValueB); //A call to the SimpleCalculation class to access the 'Add' function

            txt_ValueResult.Text = Convert.ToString(CalcResult); //Displays result 

            ScriptManager.RegisterStartupScript(this, GetType(), "openModal", "$(function () {$('#calcModal').modal();})", true); //Reopens modal

        }

        protected void btn_SubtractValues_Click(object sender, EventArgs e)
        {
            decimal ValueA = 0;
            decimal ValueB = 0;
            try
            {
                ValueA = decimal.Parse(txt_ValueA.Text);

                ValueB = decimal.Parse(txt_ValueB.Text);
            }
            catch
            {
            }

            SimpleCalculation p = new SimpleCalculation();

            decimal CalcReuslt = p.Subtract(ValueA, ValueB);

            txt_ValueResult.Text = Convert.ToString(CalcReuslt);

            ScriptManager.RegisterStartupScript(this, GetType(), "openModal", "$(function () {$('#calcModal').modal();})", true);

        }

        protected void btn_MultiplyValues_Click(object sender, EventArgs e)
        {
            decimal ValueA = 0;
            decimal ValueB = 0;
            try
            {
                ValueA = decimal.Parse(txt_ValueA.Text);

                ValueB = decimal.Parse(txt_ValueB.Text);
            }
            catch
            {
            }

            SimpleCalculation p = new SimpleCalculation();

            decimal CalcReuslt = p.Multiply(ValueA, ValueB);

            txt_ValueResult.Text = Convert.ToString(CalcReuslt);

            ScriptManager.RegisterStartupScript(this, GetType(), "openModal", "$(function () {$('#calcModal').modal();})", true);

        }

        protected void btn_DivideValues_Click(object sender, EventArgs e)
        {
            decimal ValueA = 0;
            decimal ValueB = 0;
            try
            {
                ValueA = decimal.Parse(txt_ValueA.Text);

                ValueB = decimal.Parse(txt_ValueB.Text);
            }
            catch
            {
            }

            if (ValueA == 0 || ValueB == 0) 
            {
                txt_ValueResult.Text = "Cannot divide by 0";
            }
            else
            {
                SimpleCalculation p = new SimpleCalculation();

                decimal CalcReuslt = p.Divide(ValueA, ValueB);

                txt_ValueResult.Text = Convert.ToString(CalcReuslt);
            }

            ScriptManager.RegisterStartupScript(this, GetType(), "openModal", "$(function () {$('#calcModal').modal();})", true);

        }
        protected void lstBox_Prefs_SelectedIndexChanged(object sender, EventArgs e)
        {
            string PrefsValue = lstBox_Prefs.SelectedValue; //Gets new value for the Prefs listbox input

            if (PrefsValue == "Symbols")
            {
                btn_SubtractValues.Text = "-";

                btn_AddValues.Text = "+";

                btn_MultiplyValues.Text = "*";

                btn_DivideValues.Text = "*"; //Switches button text values to symbols
            }
            if (PrefsValue == "Text")
            {
                btn_SubtractValues.Text = "Minus";

                btn_AddValues.Text = "Add";

                btn_MultiplyValues.Text = "Multiply";

                btn_DivideValues.Text = "Divide"; //Switches button text values to text
            }
        }

        protected void listBox_FontStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            string FontsValue = listBox_FontStyle.SelectedValue; //Gets new value for the Fonts listbox input

            if (FontsValue == "Times New Roman")
            {
                form_CalculatorForm.Attributes["style"] = "font-family: 'Times New Roman', Times, serif";
            }
            if (FontsValue == "Arial")
            {
                form_CalculatorForm.Attributes["style"] = "font-family: Arial";
            }
            if (FontsValue == "Lucinda")
            {
                form_CalculatorForm.Attributes["style"] = "font-family: 'Lucida Console', 'Courier New', monospace";
            }
            if (FontsValue == "Comic Sans MS")
            {
                form_CalculatorForm.Attributes["style"] = "font-family: Comic Sans MS"; //Changes the font-family in the style attribute 
            }
        }

        protected void btn_OpenCalc_Click(object sender, EventArgs e)
        {
            ScriptManager.RegisterStartupScript(this, GetType(), "openModal", "$(function () {$('#calcModal').modal();})", true); //Opens the modal
        }

    }
    }
    
    
