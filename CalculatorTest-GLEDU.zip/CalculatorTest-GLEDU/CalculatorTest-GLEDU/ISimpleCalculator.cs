﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CalculatorTest_GLEDU
{
    public interface ISimpleCalculator
    {
        decimal Add(decimal start, decimal amount);
        decimal Subtract(decimal start, decimal amount);

        decimal Divide(decimal start, decimal amount);
        decimal Multiply(decimal start, decimal amount);
    }

    public class SimpleCalculation : ISimpleCalculator
    {
        public decimal Add(decimal start, decimal amount)
        {
            decimal result;

            result = start + amount;

            return result;
        }

        public decimal Subtract(decimal start, decimal amount)
        {
            decimal result;

            result = start - amount;

            return result;
        }

        public decimal Multiply(decimal start, decimal amount)
        {
            decimal result;

            result = start * amount;

            return result;
        }

        public decimal Divide(decimal start, decimal amount)
        {
            decimal result;

            result = start / amount;

            return result;
        }
    }
}