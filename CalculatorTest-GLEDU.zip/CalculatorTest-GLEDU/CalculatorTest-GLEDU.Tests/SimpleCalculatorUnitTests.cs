﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalculatorTest_GLEDU.Tests
{
    [TestClass]
    public class SimpleCalculatorUnitTests
    {
        [TestMethod]
        public void Test_AdditionTest()
        {
            SimpleCalculation AdditionTest = new SimpleCalculation();
            decimal res = AdditionTest.Add(8, 10);
            Assert.AreEqual(res, 18);
        }
        public void Test_NegativeAdditionTest()
        {
            SimpleCalculation AdditionTest = new SimpleCalculation();
            decimal res = AdditionTest.Add(-8, -10);
            Assert.AreEqual(res, -18);
        }
        [TestMethod]
        public void Test_SubtractionTest()
        {
            SimpleCalculation SubtractionTest = new SimpleCalculation();
            decimal res = SubtractionTest.Subtract(15, 5);
            Assert.AreEqual(res, 5);
        }
        [TestMethod]
        public void Test_MultiplicationTest()
        {
            SimpleCalculation MultiplicationTest = new SimpleCalculation();
            decimal res = MultiplicationTest.Multiply(3, 6);
            Assert.AreEqual(res, 18);
        }
        [TestMethod]
        public void Test_DivisionTest()
        {
            SimpleCalculation DivisionTest = new SimpleCalculation();
            decimal res = DivisionTest.Divide(10, 2);
            Assert.AreEqual(res, 5);
        }
    }
}

